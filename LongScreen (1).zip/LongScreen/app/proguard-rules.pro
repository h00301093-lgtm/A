# Rimuove ogni chiamata di log dalla build di rilascio (nessuna traccia su logcat).
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
}
