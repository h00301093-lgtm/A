package org.longscreen.tool

import android.content.Context
import android.graphics.Bitmap
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

/**
 * Archivio locale delle catture.
 * - Percorso: memoria interna privata dell'app (files/captures), non accessibile
 *   ad altre app; cifrata dal sistema (File-Based Encryption di Android 10).
 * - Nomi dei file generati dall'app (data UTC + suffisso casuale): nessun dato
 *   dell'utente o del dispositivo compare nei nomi.
 * - Per ogni immagine un file .json con metadati minimi e impronta SHA-256
 *   (utile per la catena di custodia). Nessun identificativo di dispositivo,
 *   account, posizione o rete.
 */
object CaptureStore {

    data class Capture(val image: File, val meta: File) {
        val name: String get() = image.name
    }

    private val NAME_RE = Regex("^LS_\\d{8}T\\d{6}Z_[0-9a-f]{6}(_p\\d{1,2})?\\.(png|jpg)$")
    private val STAMP: DateTimeFormatter =
        DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'").withZone(ZoneOffset.UTC)
    private val random = SecureRandom()

    const val MAX_NOTE_LENGTH = 500

    private val _changes = MutableStateFlow(0L)
    val changes: StateFlow<Long> = _changes
    private fun notifyChanged() { _changes.value = System.nanoTime() }

    fun dir(ctx: Context): File = File(ctx.filesDir, "captures").apply { mkdirs() }

    /** Cartella temporanea per le strisce, svuotata a ogni sessione. */
    fun freshTempDir(ctx: Context): File {
        val d = File(ctx.cacheDir, "ls_tmp")
        d.deleteRecursively()
        d.mkdirs()
        return d
    }

    fun clearTemp(ctx: Context) { File(ctx.cacheDir, "ls_tmp").deleteRecursively() }

    fun list(ctx: Context): List<Capture> =
        (dir(ctx).listFiles() ?: emptyArray())
            .filter { it.isFile && NAME_RE.matches(it.name) }
            .sortedByDescending { it.name }
            .map { Capture(it, metaFileFor(it)) }

    /** Risolve un nome ricevuto (es. da Intent) SOLO se valido e interno all'archivio. */
    fun resolve(ctx: Context, name: String?): Capture? {
        if (name == null || !NAME_RE.matches(name)) return null
        val base = dir(ctx).canonicalFile
        val f = File(base, name).canonicalFile
        if (f.parentFile != base || !f.isFile) return null
        return Capture(f, metaFileFor(f))
    }

    private fun metaFileFor(image: File) = File(image.parentFile, image.nameWithoutExtension + ".json")

    fun newBaseName(now: Instant): String {
        val bytes = ByteArray(3).also { random.nextBytes(it) }
        val hex = bytes.joinToString("") { "%02x".format(it) }
        return "LS_" + STAMP.format(now) + "_" + hex
    }

    fun newSessionId(): String {
        val bytes = ByteArray(8).also { random.nextBytes(it) }
        return bytes.joinToString("") { "%02x".format(it) }
    }

    /** Scrittura atomica: file temporaneo + rename, così non restano file parziali. */
    fun saveImage(
        ctx: Context,
        bitmap: Bitmap,
        baseName: String,
        format: AppSettings.Format,
        meta: JSONObject
    ): Capture {
        val d = dir(ctx)
        val image = File(d, "$baseName.${format.extension}")
        val tmp = File(d, "$baseName.${format.extension}.part")
        try {
            FileOutputStream(tmp).use { out ->
                val ok = when (format) {
                    AppSettings.Format.PNG -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    AppSettings.Format.JPEG -> bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
                }
                if (!ok) throw IllegalStateException("compressione fallita")
                out.fd.sync()
            }
            if (!tmp.renameTo(image)) throw IllegalStateException("rename fallito")
        } finally {
            tmp.delete()
        }
        meta.put("file", image.name)
        meta.put("width", bitmap.width)
        meta.put("height", bitmap.height)
        meta.put("format", format.name)
        meta.put("bytes", image.length())
        meta.put("sha256", sha256(image))
        val capture = Capture(image, metaFileFor(image))
        writeMeta(capture, meta)
        notifyChanged()
        return capture
    }

    fun readMeta(c: Capture): JSONObject = try {
        JSONObject(c.meta.readText(Charsets.UTF_8))
    } catch (e: Exception) {
        JSONObject()
    }

    private fun writeMeta(c: Capture, meta: JSONObject) {
        val tmp = File(c.meta.parentFile, c.meta.name + ".part")
        tmp.writeText(meta.toString(2), Charsets.UTF_8)
        if (!tmp.renameTo(c.meta)) { tmp.delete(); throw IllegalStateException("meta non salvati") }
    }

    fun updateNote(c: Capture, rawNote: String) {
        val clean = sanitizeNote(rawNote)
        val meta = readMeta(c)
        meta.put("note", clean)
        writeMeta(c, meta)
        notifyChanged()
    }

    /** Rimuove caratteri di controllo e limita la lunghezza della nota. */
    fun sanitizeNote(raw: String): String =
        raw.filter { it == '\n' || !it.isISOControl() }.trim().take(MAX_NOTE_LENGTH)

    enum class Integrity { OK, ALTERED, NO_REFERENCE }

    fun verify(c: Capture): Integrity {
        val expected = readMeta(c).optString("sha256", "")
        if (expected.length != 64) return Integrity.NO_REFERENCE
        return if (MessageDigest.isEqual(expected.toByteArray(), sha256(c.image).toByteArray()))
            Integrity.OK else Integrity.ALTERED
    }

    fun delete(c: Capture) {
        c.image.delete()
        c.meta.delete()
        notifyChanged()
    }

    fun deleteAll(ctx: Context) {
        dir(ctx).listFiles()?.forEach { it.delete() }
        clearTemp(ctx)
        notifyChanged()
    }

    fun copyTo(src: File, out: OutputStream) {
        FileInputStream(src).use { it.copyTo(out) }
    }

    fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(f).use { input ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n <= 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
