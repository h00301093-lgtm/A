package org.longscreen.tool

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var settings: AppSettings
    private lateinit var adapter: CaptureAdapter
    private var pendingExport: File? = null

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == Activity.RESULT_OK && data != null) {
                ContextCompat.startForegroundService(this, CaptureService.startIntent(this, r.resultCode, data))
                Toast.makeText(this, R.string.session_started, Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, R.string.projection_denied, Toast.LENGTH_SHORT).show()
            }
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refreshStatus() }

    private val exportPng = registerForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { writeExport(it) }
    private val exportJpg = registerForActivityResult(ActivityResultContracts.CreateDocument("image/jpeg")) { writeExport(it) }
    private val exportJson = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { writeExport(it) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Impedisce screenshot dell'app stessa e l'anteprima nel menu "App recenti".
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContentView(R.layout.activity_main)
        settings = AppSettings(this)

        findViewById<Button>(R.id.btn_overlay).setOnClickListener { openOverlaySettings() }
        findViewById<Button>(R.id.btn_a11y).setOnClickListener { openA11ySettings() }
        findViewById<Button>(R.id.btn_notif).setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        findViewById<Button>(R.id.btn_start).setOnClickListener { onStartStop() }
        findViewById<Button>(R.id.btn_delete_all).setOnClickListener { confirmDeleteAll() }

        setupSettings()

        adapter = CaptureAdapter(lifecycleScope, onOpen = { openViewer(it) }, onMenu = { c, v -> showItemMenu(c, v) })
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
            isNestedScrollingEnabled = false
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { CaptureStore.changes.collect { reloadList() } }
                launch { CaptureService.running.collect { updateStartButton(it) } }
            }
        }

        if (!settings.termsAccepted) showTerms()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ---------- stato permessi ----------

    private fun refreshStatus() {
        setStatus(R.id.status_overlay, R.id.btn_overlay, Settings.canDrawOverlays(this))
        setStatus(R.id.status_a11y, R.id.btn_a11y, ScrollAccessibilityService.isEnabled(this))
        val notifRow = findViewById<View>(R.id.row_notif)
        if (Build.VERSION.SDK_INT >= 33) {
            notifRow.visibility = View.VISIBLE
            setStatus(R.id.status_notif, R.id.btn_notif,
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
        } else {
            notifRow.visibility = View.GONE
        }
    }

    private fun setStatus(statusId: Int, buttonId: Int, ok: Boolean) {
        findViewById<TextView>(statusId).apply {
            setText(if (ok) R.string.status_ok else R.string.status_missing)
            setTextColor(ContextCompat.getColor(context, if (ok) R.color.status_ok else R.color.status_missing))
        }
        findViewById<View>(buttonId).visibility = if (ok) View.GONE else View.VISIBLE
    }

    private fun openOverlaySettings() {
        val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        safeStart(i)
    }

    private fun openA11ySettings() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.a11y_dialog_title)
            .setMessage(R.string.a11y_dialog_msg)
            .setPositiveButton(R.string.open_settings) { _, _ -> safeStart(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun safeStart(i: Intent) {
        try { startActivity(i) } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.err_settings_missing, Toast.LENGTH_LONG).show()
        }
    }

    // ---------- sessione ----------

    private fun onStartStop() {
        if (CaptureService.running.value) {
            startService(CaptureService.shutdownIntent(this))
            return
        }
        if (!settings.termsAccepted) { showTerms(); return }
        if (!Settings.canDrawOverlays(this)) { openOverlaySettings(); return }
        if (!ScrollAccessibilityService.isEnabled(this)) { openA11ySettings(); return }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun updateStartButton(running: Boolean) {
        findViewById<Button>(R.id.btn_start).setText(if (running) R.string.btn_stop_session else R.string.btn_start_session)
        findViewById<TextView>(R.id.session_hint).setText(if (running) R.string.hint_running else R.string.hint_idle)
    }

    private fun showTerms() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.terms_title)
            .setMessage(R.string.terms_msg)
            .setCancelable(false)
            .setPositiveButton(R.string.terms_accept) { _, _ -> settings.termsAccepted = true }
            .setNegativeButton(R.string.terms_decline) { _, _ -> finish() }
            .show()
    }

    // ---------- impostazioni ----------

    private fun setupSettings() {
        bindToggle(R.id.tg_step, mapOf(
            R.id.step_short to AppSettings.Step.SHORT,
            R.id.step_medium to AppSettings.Step.MEDIUM,
            R.id.step_long to AppSettings.Step.LONG
        ), settings.step) { settings.step = it }
        bindToggle(R.id.tg_settle, mapOf(
            R.id.settle_normal to AppSettings.Settle.NORMAL,
            R.id.settle_slow to AppSettings.Settle.SLOW
        ), settings.settle) { settings.settle = it }
        bindToggle(R.id.tg_height, mapOf(
            R.id.h_10 to 10_000, R.id.h_20 to 20_000, R.id.h_30 to 30_000
        ), settings.maxHeight) { settings.maxHeight = it }
        bindToggle(R.id.tg_format, mapOf(
            R.id.fmt_png to AppSettings.Format.PNG,
            R.id.fmt_jpg to AppSettings.Format.JPEG
        ), settings.format) { settings.format = it }

        findViewById<MaterialSwitch>(R.id.sw_bars).apply {
            isChecked = settings.stripSystemBars
            setOnCheckedChangeListener { _, checked -> settings.stripSystemBars = checked }
        }
    }

    private fun <T> bindToggle(groupId: Int, options: Map<Int, T>, current: T, onChange: (T) -> Unit) {
        val group = findViewById<MaterialButtonToggleGroup>(groupId)
        options.entries.firstOrNull { it.value == current }?.let { group.check(it.key) }
        group.addOnButtonCheckedListener { _, id, checked ->
            if (checked) options[id]?.let(onChange)
        }
    }

    // ---------- archivio ----------

    private fun reloadList() {
        lifecycleScope.launch {
            val items = withContext(Dispatchers.IO) {
                CaptureStore.list(this@MainActivity).map { it to CaptureStore.readMeta(it) }
            }
            adapter.submit(items)
            findViewById<View>(R.id.empty).visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            findViewById<View>(R.id.btn_delete_all).visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    private fun openViewer(c: CaptureStore.Capture) {
        startActivity(Intent(this, ViewerActivity::class.java).putExtra(ViewerActivity.EXTRA_NAME, c.name))
    }

    private fun showItemMenu(c: CaptureStore.Capture, anchor: View) {
        val popup = androidx.appcompat.widget.PopupMenu(this, anchor)
        popup.menuInflater.inflate(R.menu.capture_item, popup.menu)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.m_view -> openViewer(c)
                R.id.m_note -> editNote(c)
                R.id.m_export_img -> {
                    pendingExport = c.image
                    if (c.image.extension == "png") exportPng.launch(c.image.name) else exportJpg.launch(c.image.name)
                }
                R.id.m_export_meta -> { pendingExport = c.meta; exportJson.launch(c.meta.name) }
                R.id.m_verify -> verify(c)
                R.id.m_delete -> confirmDelete(c)
            }
            true
        }
        popup.show()
    }

    private fun writeExport(uri: Uri?) {
        val src = pendingExport
        pendingExport = null
        if (uri == null || src == null) return
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openOutputStream(uri, "w")?.use { CaptureStore.copyTo(src, it) } != null
                } catch (e: Exception) {
                    SecureLog.w("export fallito", e); false
                }
            }
            Toast.makeText(this@MainActivity, if (ok) R.string.export_ok else R.string.export_fail, Toast.LENGTH_SHORT).show()
        }
    }

    private fun editNote(c: CaptureStore.Capture) {
        val layout = layoutInflater.inflate(R.layout.dialog_note, null)
        val til = layout.findViewById<TextInputLayout>(R.id.note_layout)
        val input = layout.findViewById<TextInputEditText>(R.id.note_input)
        til.isCounterEnabled = true
        til.counterMaxLength = CaptureStore.MAX_NOTE_LENGTH
        input.filters = arrayOf(InputFilter.LengthFilter(CaptureStore.MAX_NOTE_LENGTH))
        lifecycleScope.launch {
            val current = withContext(Dispatchers.IO) { CaptureStore.readMeta(c).optString("note", "") }
            input.setText(current)
            MaterialAlertDialogBuilder(this@MainActivity)
                .setTitle(R.string.note_title)
                .setView(layout)
                .setPositiveButton(R.string.save) { _, _ ->
                    val text = input.text?.toString().orEmpty()
                    lifecycleScope.launch(Dispatchers.IO) {
                        try { CaptureStore.updateNote(c, text) } catch (e: Exception) { SecureLog.w("nota", e) }
                    }
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
    }

    private fun verify(c: CaptureStore.Capture) {
        lifecycleScope.launch {
            val r = withContext(Dispatchers.IO) { CaptureStore.verify(c) }
            val msg = when (r) {
                CaptureStore.Integrity.OK -> R.string.verify_ok
                CaptureStore.Integrity.ALTERED -> R.string.verify_altered
                CaptureStore.Integrity.NO_REFERENCE -> R.string.verify_noref
            }
            MaterialAlertDialogBuilder(this@MainActivity)
                .setTitle(R.string.verify_title).setMessage(msg)
                .setPositiveButton(android.R.string.ok, null).show()
        }
    }

    private fun confirmDelete(c: CaptureStore.Capture) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.delete_title)
            .setMessage(R.string.delete_msg)
            .setPositiveButton(R.string.delete) { _, _ ->
                lifecycleScope.launch(Dispatchers.IO) { CaptureStore.delete(c) }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun confirmDeleteAll() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.delete_all_title)
            .setMessage(R.string.delete_all_msg)
            .setPositiveButton(R.string.delete_all) { _, _ ->
                lifecycleScope.launch(Dispatchers.IO) { CaptureStore.deleteAll(this@MainActivity) }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
