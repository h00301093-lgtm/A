package org.longscreen.tool

import android.util.Log

/**
 * Log minimale: attivo solo in debug e MAI con contenuti catturati, percorsi
 * completi o dati dell'utente. In release R8 elimina comunque ogni chiamata a Log.
 */
object SecureLog {
    private const val TAG = "LongScreen"

    fun d(msg: String) {
        if (BuildConfig.DEBUG) Log.d(TAG, msg)
    }

    fun w(msg: String, t: Throwable? = null) {
        // Si registra solo il tipo di eccezione, non il messaggio (potrebbe contenere percorsi).
        if (BuildConfig.DEBUG) Log.w(TAG, msg + (t?.let { " [" + it.javaClass.simpleName + "]" } ?: ""))
    }
}
