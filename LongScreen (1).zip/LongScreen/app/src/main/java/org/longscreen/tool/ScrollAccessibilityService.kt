package org.longscreen.tool

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.provider.Settings
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/**
 * Servizio di accessibilità con privilegi minimi:
 *  - esegue gesti di scorrimento (canPerformGestures);
 *  - durante una cattura intercetta i tasti volume per interromperla.
 * NON legge testi, nodi o contenuti delle finestre (canRetrieveWindowContent=false)
 * e ignora ogni evento di accessibilità.
 */
class ScrollAccessibilityService : AccessibilityService() {

    /** true solo mentre è in corso una cattura: fuori da quel momento i tasti non vengono toccati. */
    @Volatile var captureActive: Boolean = false
    @Volatile var onStopKey: (() -> Unit)? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* volutamente ignorati */ }

    override fun onInterrupt() { captureActive = false }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!captureActive) return false
        val isVolume = event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            event.keyCode == KeyEvent.KEYCODE_VOLUME_UP
        if (!isVolume) return false
        if (event.action == KeyEvent.ACTION_UP) onStopKey?.invoke()
        return true // il tasto non cambia il volume durante la cattura
    }

    /**
     * Trascina il contenuto verso l'alto da [fromY] a [toY]; poi tiene il "dito" fermo
     * per [holdMs] prima di sollevarlo, così la velocità finale è ~0 e non parte l'inerzia
     * (fling), che renderebbe imprevedibile lo spostamento.
     */
    suspend fun swipeUp(x: Float, fromY: Float, toY: Float, moveMs: Long, holdMs: Long): Boolean {
        val movePath = Path().apply { moveTo(x, fromY); lineTo(x, toY) }
        val move = GestureDescription.StrokeDescription(movePath, 0L, moveMs, true)
        if (!dispatch(GestureDescription.Builder().addStroke(move).build())) return false

        val holdPath = Path().apply { moveTo(x, toY); lineTo(x, toY - 1f) }
        val hold = move.continueStroke(holdPath, 0L, holdMs, false)
        dispatch(GestureDescription.Builder().addStroke(hold).build())
        return true
    }

    private suspend fun dispatch(gesture: GestureDescription): Boolean =
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { cont ->
                val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                    override fun onCompleted(g: GestureDescription?) { if (cont.isActive) cont.resume(true) }
                    override fun onCancelled(g: GestureDescription?) { if (cont.isActive) cont.resume(false) }
                }, null)
                if (!accepted && cont.isActive) cont.resume(false)
            }
        }

    companion object {
        @Volatile var instance: ScrollAccessibilityService? = null
            private set

        fun isEnabled(context: Context): Boolean {
            val expected = ComponentName(context, ScrollAccessibilityService::class.java)
            val enabled = Settings.Secure.getString(
                context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return enabled.split(':').any { ComponentName.unflattenFromString(it) == expected }
        }
    }
}
