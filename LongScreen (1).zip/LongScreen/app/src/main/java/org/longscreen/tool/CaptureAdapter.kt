package org.longscreen.tool

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class CaptureAdapter(
    private val scope: CoroutineScope,
    private val onOpen: (CaptureStore.Capture) -> Unit,
    private val onMenu: (CaptureStore.Capture, View) -> Unit
) : RecyclerView.Adapter<CaptureAdapter.VH>() {

    private var items: List<Pair<CaptureStore.Capture, JSONObject>> = emptyList()
    private val dateFmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss").withZone(ZoneId.systemDefault())

    fun submit(newItems: List<Pair<CaptureStore.Capture, JSONObject>>) {
        items = newItems
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val title: TextView = v.findViewById(R.id.title)
        val subtitle: TextView = v.findViewById(R.id.subtitle)
        val note: TextView = v.findViewById(R.id.note)
        val menu: ImageButton = v.findViewById(R.id.menu)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_capture, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val (c, meta) = items[position]
        val ctx = h.itemView.context
        val created = meta.optString("created_utc", "")
        h.title.text = try { dateFmt.format(Instant.parse(created)) } catch (e: Exception) { c.name }
        val parts = meta.optInt("parts", 1)
        val partTxt = if (parts > 1) " · " + ctx.getString(R.string.part_of, meta.optInt("part", 1), parts) else ""
        h.subtitle.text = ctx.getString(
            R.string.item_subtitle,
            meta.optInt("width"), meta.optInt("height"),
            Formatter.formatShortFileSize(ctx, c.image.length())
        ) + partTxt
        val note = meta.optString("note", "")
        h.note.text = note
        h.note.visibility = if (note.isEmpty()) View.GONE else View.VISIBLE

        h.itemView.setOnClickListener { onOpen(c) }
        h.menu.setOnClickListener { onMenu(c, it) }
        h.itemView.contentDescription = h.title.text

        h.thumb.setImageDrawable(null)
        h.thumb.tag = c.name
        scope.launch {
            val bmp = withContext(Dispatchers.IO) { decodeTop(c) }
            if (h.thumb.tag == c.name) h.thumb.setImageBitmap(bmp)
        }
    }

    /** Decodifica solo la parte alta dell'immagine, sottocampionata: memoria minima. */
    private fun decodeTop(c: CaptureStore.Capture): Bitmap? = try {
        @Suppress("DEPRECATION")
        val dec = BitmapRegionDecoder.newInstance(c.image.path, false)
        try {
            val w = dec.width
            val hgt = minOf(dec.height, (w * 1.4f).toInt())
            dec.decodeRegion(Rect(0, 0, w, hgt), BitmapFactory.Options().apply { inSampleSize = 8 })
        } finally { dec.recycle() }
    } catch (e: Exception) { null }
}
