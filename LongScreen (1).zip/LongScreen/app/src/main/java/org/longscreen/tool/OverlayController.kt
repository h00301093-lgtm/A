package org.longscreen.tool

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import kotlin.math.abs

/** Pulsante flottante trascinabile sopra le altre app. Nessuna lettura di input altrui. */
class OverlayController(context: Context, private val onTap: () -> Unit) {

    private val ctx = ContextThemeWrapper(context, R.style.Theme_LongScreen)
    private val wm = context.getSystemService(WindowManager::class.java)
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var view: View? = null

    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 24
        y = 480
    }

    val isShown: Boolean get() = view != null

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    fun show() {
        if (view != null) return
        val v = LayoutInflater.from(ctx).inflate(R.layout.overlay_button, null)
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        v.setOnTouchListener { target, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = params.x; startY = params.y; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (moved || abs(dx) > slop || abs(dy) > slop) {
                        moved = true
                        params.x = (startX + dx).toInt()
                        params.y = (startY + dy).toInt()
                        try { wm.updateViewLayout(target, params) } catch (_: IllegalArgumentException) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) target.performClick(); true }
                else -> false
            }
        }
        v.setOnClickListener { onTap() }
        try {
            wm.addView(v, params)
            view = v
        } catch (e: RuntimeException) {
            SecureLog.w("overlay non mostrato", e)
        }
    }

    fun hide() {
        val v = view ?: return
        try { wm.removeViewImmediate(v) } catch (_: IllegalArgumentException) {}
        view = null
    }
}
