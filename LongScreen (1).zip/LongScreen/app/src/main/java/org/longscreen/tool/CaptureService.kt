package org.longscreen.tool

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.ViewConfiguration
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.IntentCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.time.Instant

/**
 * Servizio in primo piano che possiede la MediaProjection per tutta la sessione.
 * La cattura parte SOLO quando l'utente tocca il pulsante flottante; in ogni altro
 * momento nessun fotogramma viene letto o conservato.
 */
class CaptureService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val main = Handler(Looper.getMainLooper())

    private var projection: MediaProjection? = null
    private var grabber: FrameGrabber? = null
    private var overlay: OverlayController? = null
    private var captureJob: Job? = null
    @Volatile private var stopRequested = false

    private data class Screen(val width: Int, val height: Int, val dpi: Int, val statusBar: Int, val navBar: Int)
    private lateinit var screen: Screen

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startSession(intent)
            ACTION_STOP_CAPTURE -> stopRequested = true
            ACTION_SHUTDOWN -> stopSelf()
            else -> stopSelf()
        }
        return START_NOT_STICKY // mai riavviato automaticamente dal sistema
    }

    private fun startSession(intent: Intent) {
        // startForeground va chiamato subito: un servizio avviato con
        // startForegroundService che si ferma prima causerebbe un crash.
        createChannel()
        startForeground(
            NOTIF_ID, buildNotification(getString(R.string.notif_ready)),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )
        if (projection != null) { overlay?.show(); return }
        val code = intent.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return }

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val mp = try { mpm.getMediaProjection(code, data) } catch (e: RuntimeException) { null }
        if (mp == null) { toast(R.string.err_projection); stopSelf(); return }
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)
        projection = mp

        screen = readScreen()
        grabber = FrameGrabber(mp, screen.width, screen.height, screen.dpi)
        overlay = OverlayController(this) { onOverlayTap() }.also { it.show() }
        _running.value = true
    }

    private fun onOverlayTap() {
        if (captureJob?.isActive == true) return
        val a11y = ScrollAccessibilityService.instance
        if (a11y == null) { toast(R.string.err_a11y_off); return }
        stopRequested = false
        captureJob = scope.launch { runCapture(a11y) }
    }

    private suspend fun runCapture(a11y: ScrollAccessibilityService) {
        val g = grabber ?: return
        val settings = AppSettings(this)
        val tempDir = CaptureStore.freshTempDir(this)
        val cropTop = if (settings.stripSystemBars) screen.statusBar else 0
        val cropBottom = if (settings.stripSystemBars) screen.navBar else 0
        val session = StitchSession(tempDir, cropTop, cropBottom)
        var endReason = END_CONTENT

        withContext(Dispatchers.Main) {
            overlay?.hide()
            updateNotification(getString(R.string.notif_capturing))
        }
        a11y.onStopKey = { stopRequested = true }
        a11y.captureActive = true

        try {
            delay(350) // il pulsante flottante deve sparire dallo schermo
            g.awaitStable(settings.settle.quietMs, settings.settle.maxMs)
            val first = g.snapshot() ?: throw IllegalStateException("nessun fotogramma")
            if (isMostlyBlack(first)) {
                first.recycle()
                toast(R.string.err_secure_window)
                return
            }
            session.start(first)

            val h = screen.height.toFloat()
            val stepPx = h * settings.step.screenFraction
            val fromY = h * 0.72f
            val toY = fromY - stepPx
            val x = screen.width * 0.5f
            val expected = (stepPx - ViewConfiguration.get(this).scaledTouchSlop).toInt()
            val maxHeight = settings.maxHeight

            while (true) {
                if (stopRequested) { endReason = END_USER; break }
                if (session.totalHeight >= maxHeight) { endReason = END_LIMIT; break }
                if (session.frames >= MAX_FRAMES) { endReason = END_LIMIT; break }

                if (!a11y.swipeUp(x, fromY, toY, moveMs = 650, holdMs = 180)) {
                    endReason = END_GESTURE; break
                }
                g.awaitStable(settings.settle.quietMs, settings.settle.maxMs)
                val cur = g.snapshot()
                if (cur == null) { endReason = END_GESTURE; break }
                when (session.add(cur, expected)) {
                    StitchSession.Step.CONTINUE -> Unit
                    StitchSession.Step.END_OF_CONTENT -> { endReason = END_CONTENT; break }
                    StitchSession.Step.MISALIGNED -> { endReason = END_MISALIGNED; break }
                }
            }
            session.finish()

            withContext(Dispatchers.Main) { updateNotification(getString(R.string.notif_saving)) }
            val saved = save(session, settings, endReason)
            toast(when {
                endReason == END_MISALIGNED -> R.string.saved_misaligned
                saved > 1 -> R.string.saved_parts
                else -> R.string.saved_one
            })
        } catch (e: CancellationException) {
            session.discard()
            throw e
        } catch (e: OutOfMemoryError) {
            session.discard()
            toast(R.string.err_memory)
        } catch (e: Exception) {
            SecureLog.w("cattura fallita", e)
            session.discard()
            toast(R.string.err_generic)
        } finally {
            a11y.captureActive = false
            a11y.onStopKey = null
            CaptureStore.clearTemp(this)
            withContext(Dispatchers.Main + NonCancellable) {
                if (projection != null) {
                    overlay?.show()
                    updateNotification(getString(R.string.notif_ready))
                }
            }
        }
    }

    private fun save(session: StitchSession, settings: AppSettings, endReason: String): Int {
        val now = Instant.now()
        val sessionId = CaptureStore.newSessionId()
        val base = CaptureStore.newBaseName(now)
        val maxPart = StitchSession.maxPartHeightFor(session.width)
        var parts = 0
        val totalParts = countParts(session.strips, maxPart)
        StitchSession.assemble(session.strips, session.width, maxPart) { bmp, index ->
            val name = if (totalParts > 1) base + "_p" + (index + 1) else base
            val meta = JSONObject().apply {
                put("tool", "Long screen")
                put("tool_version", BuildConfig.VERSION_NAME)
                put("created_utc", now.toString())
                put("session_id", sessionId)
                put("part", index + 1)
                put("parts", totalParts)
                put("frames", session.frames)
                put("uncertain_joins", session.weakJoins)
                put("end_reason", endReason)
                put("system_bars_removed", settings.stripSystemBars)
                put("note", "")
            }
            CaptureStore.saveImage(this, bmp, name, settings.format, meta)
            parts++
        }
        session.strips.forEach { it.file.delete() }
        return parts
    }

    private fun countParts(strips: List<StitchSession.Strip>, maxPart: Int): Int {
        var parts = 1; var h = 0
        for (s in strips) {
            if (h + s.height > maxPart && h > 0) { parts++; h = 0 }
            h += s.height
        }
        return parts
    }

    /** Le finestre protette (FLAG_SECURE: app bancarie, chat segrete…) risultano nere. */
    private fun isMostlyBlack(b: Bitmap): Boolean {
        var dark = 0; var n = 0
        val stepX = maxOf(1, b.width / 12); val stepY = maxOf(1, b.height / 24)
        var y = stepY / 2
        while (y < b.height) {
            var x = stepX / 2
            while (x < b.width) {
                val p = b.getPixel(x, y)
                if (((p shr 16) and 0xFF) < 8 && ((p shr 8) and 0xFF) < 8 && (p and 0xFF) < 8) dark++
                n++; x += stepX
            }
            y += stepY
        }
        return n > 0 && dark >= n * 0.97
    }

    @Suppress("DEPRECATION")
    private fun readScreen(): Screen {
        val wm = getSystemService(WindowManager::class.java)
        val dpi = resources.displayMetrics.densityDpi
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val m = wm.maximumWindowMetrics
            val insets = m.windowInsets
            Screen(
                m.bounds.width(), m.bounds.height(), dpi,
                insets.getInsets(WindowInsets.Type.statusBars()).top,
                insets.getInsets(WindowInsets.Type.navigationBars()).bottom
            )
        } else {
            val real = DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it) }
            val app = DisplayMetrics().also { wm.defaultDisplay.getMetrics(it) }
            val id = resources.getIdentifier("status_bar_height", "dimen", "android")
            val status = if (id > 0) resources.getDimensionPixelSize(id) else 0
            val nav = (real.heightPixels - app.heightPixels).coerceAtLeast(0)
            Screen(real.widthPixels, real.heightPixels, dpi, status, nav)
        }
    }

    // ---------- notifiche ----------

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW)
                    .apply { setShowBadge(false); lockscreenVisibility = Notification.VISIBILITY_SECRET }
            )
        }
    }

    private fun servicePending(action: String, req: Int): PendingIntent =
        PendingIntent.getService(
            this, req, Intent(this, CaptureService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_capture)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .setContentIntent(open)
            .addAction(0, getString(R.string.action_stop_capture), servicePending(ACTION_STOP_CAPTURE, 1))
            .addAction(0, getString(R.string.action_shutdown), servicePending(ACTION_SHUTDOWN, 2))
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    private fun toast(resId: Int) {
        main.post { Toast.makeText(applicationContext, resId, Toast.LENGTH_LONG).show() }
    }

    override fun onDestroy() {
        _running.value = false
        stopRequested = true
        scope.cancel()
        overlay?.hide(); overlay = null
        grabber?.release(); grabber = null
        try { projection?.stop() } catch (_: RuntimeException) {}
        projection = null
        ScrollAccessibilityService.instance?.captureActive = false
        CaptureStore.clearTemp(this)
        super.onDestroy()
    }

    companion object {
        private const val ACTION_START = "org.longscreen.tool.START"
        private const val ACTION_STOP_CAPTURE = "org.longscreen.tool.STOP_CAPTURE"
        private const val ACTION_SHUTDOWN = "org.longscreen.tool.SHUTDOWN"
        private const val EXTRA_CODE = "code"
        private const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "capture_session"
        private const val NOTIF_ID = 42
        private const val MAX_FRAMES = 300

        const val END_CONTENT = "end_of_content"
        const val END_LIMIT = "height_limit"
        const val END_USER = "stopped_by_user"
        const val END_MISALIGNED = "alignment_uncertain"
        const val END_GESTURE = "scroll_gesture_failed"

        private val _running = MutableStateFlow(false)
        val running: StateFlow<Boolean> = _running

        fun startIntent(ctx: Context, code: Int, data: Intent): Intent =
            Intent(ctx, CaptureService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_CODE, code)
                .putExtra(EXTRA_DATA, data)

        fun shutdownIntent(ctx: Context): Intent =
            Intent(ctx, CaptureService::class.java).setAction(ACTION_SHUTDOWN)
    }
}
