package org.longscreen.tool

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import android.os.Bundle
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Visualizzatore interno: l'immagine lunga viene mostrata a "tessere" decodificate
 * al volo, così anche immagini di decine di migliaia di pixel restano fluide e il
 * file non esce mai dall'app per essere visualizzato.
 */
class ViewerActivity : AppCompatActivity() {

    private var decoder: BitmapRegionDecoder? = null
    private val decodeLock = Mutex()
    private val cache = object : LruCache<Int, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: Int, value: Bitmap) = value.byteCount
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContentView(R.layout.activity_viewer)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setNavigationOnClickListener { finish() }

        val capture = CaptureStore.resolve(this, intent.getStringExtra(EXTRA_NAME))
        if (capture == null) {
            Toast.makeText(this, R.string.err_not_found, Toast.LENGTH_SHORT).show()
            finish(); return
        }

        lifecycleScope.launch {
            val (dec, meta) = withContext(Dispatchers.IO) {
                @Suppress("DEPRECATION")
                val d = try { BitmapRegionDecoder.newInstance(capture.image.path, false) } catch (e: Exception) { null }
                d to CaptureStore.readMeta(capture)
            }
            if (dec == null) {
                Toast.makeText(this@ViewerActivity, R.string.err_not_found, Toast.LENGTH_SHORT).show()
                finish(); return@launch
            }
            decoder = dec
            val sha = meta.optString("sha256", "")
            findViewById<TextView>(R.id.info).text = getString(
                R.string.viewer_info, dec.width, dec.height,
                if (sha.length >= 16) sha.substring(0, 16) + "…" else "—"
            )
            val note = meta.optString("note", "")
            findViewById<TextView>(R.id.viewer_note).apply {
                text = note; visibility = if (note.isEmpty()) View.GONE else View.VISIBLE
            }
            findViewById<RecyclerView>(R.id.tiles).apply {
                layoutManager = LinearLayoutManager(this@ViewerActivity)
                setItemViewCacheSize(4)
                adapter = TileAdapter(dec.width, dec.height)
            }
        }
    }

    override fun onDestroy() {
        cache.evictAll()
        val d = decoder
        decoder = null
        // Rilascio sotto lo stesso lock della decodifica: mai durante una decodeRegion in corso.
        if (d != null) CoroutineScope(Dispatchers.IO).launch { decodeLock.withLock { d.recycle() } }
        super.onDestroy()
    }

    private inner class TileAdapter(private val imgW: Int, private val imgH: Int) :
        RecyclerView.Adapter<TileAdapter.VH>() {

        private val count = (imgH + TILE - 1) / TILE

        inner class VH(val image: ImageView) : RecyclerView.ViewHolder(image)

        override fun getItemCount() = count

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val iv = LayoutInflater.from(parent.context).inflate(R.layout.item_tile, parent, false) as ImageView
            return VH(iv)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val top = position * TILE
            val tileH = minOf(TILE, imgH - top)
            val viewW = h.itemView.resources.displayMetrics.widthPixels
            h.image.layoutParams = h.image.layoutParams.apply {
                height = (tileH.toLong() * viewW / imgW).toInt().coerceAtLeast(1)
            }
            h.image.tag = position
            val cached = cache.get(position)
            if (cached != null) { h.image.setImageBitmap(cached); return }
            h.image.setImageDrawable(null)
            lifecycleScope.launch {
                val bmp = withContext(Dispatchers.IO) {
                    decodeLock.withLock {
                        val d = decoder ?: return@withLock null
                        try {
                            val opts = BitmapFactory.Options().apply {
                                inSampleSize = if (imgW >= viewW * 2) 2 else 1
                            }
                            d.decodeRegion(Rect(0, top, imgW, top + tileH), opts)
                        } catch (e: Exception) { null }
                    }
                }
                if (bmp != null) {
                    cache.put(position, bmp)
                    if (h.image.tag == position) h.image.setImageBitmap(bmp)
                }
            }
        }
    }

    companion object {
        const val EXTRA_NAME = "name"
        private const val TILE = 1024
    }
}
