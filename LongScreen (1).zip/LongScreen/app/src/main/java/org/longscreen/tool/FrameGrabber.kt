package org.longscreen.tool

import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import kotlinx.coroutines.delay

/**
 * Riceve i fotogrammi dello schermo tramite MediaProjection. Tiene in memoria solo
 * l'ultimo fotogramma (nessuna registrazione continua, nessun buffer storico).
 */
class FrameGrabber(
    projection: MediaProjection,
    val width: Int,
    val height: Int,
    densityDpi: Int
) {
    private val thread = HandlerThread("ls-frames").apply { start() }
    private val handler = Handler(thread.looper)
    private val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
    private val lock = Any()
    private var latest: Image? = null
    private var display: VirtualDisplay? = null

    @Volatile private var lastFrameAt = 0L

    init {
        reader.setOnImageAvailableListener({ r ->
            val img = try { r.acquireLatestImage() } catch (e: IllegalStateException) { null }
            if (img != null) {
                synchronized(lock) {
                    latest?.close()
                    latest = img
                }
                lastFrameAt = SystemClock.uptimeMillis()
            }
        }, handler)

        display = projection.createVirtualDisplay(
            "longscreen", width, height, densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, handler
        )
    }

    /** Attende che lo schermo smetta di cambiare (animazioni, caricamenti, inerzia). */
    suspend fun awaitStable(quietMs: Long, maxMs: Long) {
        val start = SystemClock.uptimeMillis()
        delay(80)
        while (true) {
            val now = SystemClock.uptimeMillis()
            if (now - lastFrameAt >= quietMs || now - start >= maxMs) return
            delay(40)
        }
    }

    /** Copia l'ultimo fotogramma in una Bitmap indipendente. */
    fun snapshot(): Bitmap? = synchronized(lock) {
        val img = latest ?: return null
        try {
            val plane = img.planes[0]
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val paddedWidth = rowStride / pixelStride
            val buffer = plane.buffer.also { it.rewind() }
            val padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
            padded.copyPixelsFromBuffer(buffer)
            if (paddedWidth == width) padded
            else Bitmap.createBitmap(padded, 0, 0, width, height).also { padded.recycle() }
        } catch (e: RuntimeException) {
            SecureLog.w("snapshot fallito", e)
            null
        }
    }

    fun release() {
        try { display?.release() } catch (_: RuntimeException) {}
        display = null
        reader.setOnImageAvailableListener(null, null)
        synchronized(lock) { latest?.close(); latest = null }
        try { reader.close() } catch (_: RuntimeException) {}
        thread.quitSafely()
    }
}
