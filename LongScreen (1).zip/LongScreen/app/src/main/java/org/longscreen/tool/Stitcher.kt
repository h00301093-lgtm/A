package org.longscreen.tool

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * "Firma" di ogni riga di pixel: un hash dei pixel campionati (escludendo i bordi,
 * dove compaiono barre di scorrimento che si dissolvono) e un flag che indica se la
 * riga contiene informazione (non è una riga uniforme, es. sfondo bianco).
 */
class Frame(val bitmap: Bitmap) {
    val height = bitmap.height
    val sig = LongArray(height)
    val informative = BooleanArray(height)

    init {
        val w = bitmap.width
        val row = IntArray(w)
        val x0 = (w * 0.04f).toInt()
        val x1 = (w * 0.93f).toInt()
        for (y in 0 until height) {
            bitmap.getPixels(row, 0, w, 0, y, w, 1)
            var h = 1125899906842597L
            var mn = Int.MAX_VALUE
            var mx = Int.MIN_VALUE
            var x = x0
            while (x < x1) {
                val p = row[x] and 0xFFFFFF
                h = 31 * h + p
                val lum = ((p shr 16) and 0xFF) + ((p shr 8) and 0xFF) + (p and 0xFF)
                if (lum < mn) mn = lum
                if (lum > mx) mx = lum
                x += 2
            }
            sig[y] = h
            informative[y] = (mx - mn) > 30
        }
    }
}

sealed class Offset {
    object NoMovement : Offset()
    data class Found(val shift: Int, val score: Float) : Offset()
    object Failed : Offset()
}

object OffsetFinder {
    /**
     * Trova di quanti pixel [cur] è scorso rispetto a [prev] nella finestra [top, bottom):
     * cerca lo spostamento s tale che cur[y] == prev[y + s] per la maggior parte delle
     * righe informative. A parità di punteggio sceglie il valore più vicino a [expected].
     */
    fun find(prev: Frame, cur: Frame, top: Int, bottom: Int, expected: Int): Offset {
        val winH = bottom - top
        if (winH < 100) return Offset.Failed

        var identical = 0
        for (y in top until bottom) if (prev.sig[y] == cur.sig[y]) identical++
        if (identical >= winH * 0.985f) return Offset.NoMovement

        val minOverlap = max(winH / 5, 60)
        var bestS = -1
        var bestScore = -1f
        for (s in 1..(winH - minOverlap)) {
            var inf = 0
            var match = 0
            for (y in top until bottom - s) {
                if (cur.informative[y]) {
                    inf++
                    if (cur.sig[y] == prev.sig[y + s]) match++
                }
            }
            if (inf < 15) continue
            val score = match.toFloat() / inf
            val better = score > bestScore + 0.005f ||
                (abs(score - bestScore) <= 0.005f && abs(s - expected) < abs(bestS - expected))
            if (better) { bestScore = score; bestS = s }
        }
        return if (bestS > 0 && bestScore >= MIN_SCORE) Offset.Found(bestS, bestScore) else Offset.Failed
    }

    fun staticTop(a: Frame, b: Frame, cap: Int): Int {
        var y = 0
        while (y < cap && a.sig[y] == b.sig[y]) y++
        return y
    }

    fun staticBottom(a: Frame, b: Frame, cap: Int): Int {
        var n = 0
        val h = a.height
        while (n < cap && a.sig[h - 1 - n] == b.sig[h - 1 - n]) n++
        return n
    }

    const val MIN_SCORE = 0.80f
    const val WEAK_SCORE = 0.92f
}

/**
 * Sessione di cucitura. Le strisce vengono scritte subito su disco (cache privata,
 * PNG senza perdita) così in RAM restano al massimo due fotogrammi.
 */
class StitchSession(
    private val tempDir: File,
    private val cropTop: Int,
    private val cropBottom: Int
) {
    data class Strip(val file: File, val height: Int)

    enum class Step { CONTINUE, END_OF_CONTENT, MISALIGNED }

    val strips = mutableListOf<Strip>()
    var totalHeight = 0; private set
    var frames = 0; private set
    var weakJoins = 0; private set
    var width = 0; private set

    private var prev: Frame? = null
    private var footer = 0
    private var firstWritten = false
    private var screenH = 0

    fun start(first: Bitmap) {
        prev = Frame(first)
        width = first.width
        screenH = first.height
        frames = 1
    }

    fun add(bitmap: Bitmap, expectedShift: Int): Step {
        val p = prev ?: error("sessione non avviata")
        val cur = Frame(bitmap)
        frames++

        val candidateFooter = if (firstWritten) footer
            else OffsetFinder.staticBottom(p, cur, (screenH * 0.30f).toInt())
        val top = OffsetFinder.staticTop(p, cur, (screenH * 0.45f).toInt())
        val bottom = screenH - candidateFooter

        return when (val r = OffsetFinder.find(p, cur, top, bottom, expectedShift)) {
            is Offset.NoMovement -> { bitmap.recycle(); Step.END_OF_CONTENT }
            is Offset.Failed -> { bitmap.recycle(); Step.MISALIGNED }
            is Offset.Found -> {
                if (!firstWritten) {
                    footer = candidateFooter
                    writeStrip(p.bitmap, cropTop, screenH - footer)
                    firstWritten = true
                }
                if (r.score < OffsetFinder.WEAK_SCORE) weakJoins++
                writeStrip(cur.bitmap, screenH - footer - r.shift, screenH - footer)
                p.bitmap.recycle()
                prev = cur
                Step.CONTINUE
            }
        }
    }

    /** Chiude la sessione aggiungendo la parte fissa inferiore (una sola volta). */
    fun finish() {
        val p = prev ?: return
        if (!firstWritten) {
            writeStrip(p.bitmap, cropTop, screenH - cropBottom)
        } else {
            writeStrip(p.bitmap, screenH - footer, screenH - cropBottom)
        }
        p.bitmap.recycle()
        prev = null
    }

    fun discard() {
        prev?.bitmap?.recycle()
        prev = null
        strips.forEach { it.file.delete() }
        strips.clear()
    }

    private fun writeStrip(src: Bitmap, y0Raw: Int, y1Raw: Int) {
        val y0 = y0Raw.coerceIn(0, src.height)
        val y1 = y1Raw.coerceIn(0, src.height)
        if (y1 <= y0) return
        val sub = Bitmap.createBitmap(src, 0, y0, src.width, y1 - y0)
        val f = File(tempDir, "strip_%04d.png".format(strips.size))
        try {
            FileOutputStream(f).use { sub.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } finally {
            if (sub !== src) sub.recycle()
        }
        strips += Strip(f, y1 - y0)
        totalHeight += y1 - y0
    }

    companion object {
        /**
         * Ricompone le strisce. Se l'immagine richiederebbe troppa memoria viene
         * divisa in più parti (ognuna ≤ [maxPartHeight]) invece di andare in crash.
         */
        fun assemble(
            strips: List<Strip>,
            width: Int,
            maxPartHeight: Int,
            writePart: (Bitmap, Int) -> Unit
        ) {
            val parts = mutableListOf<MutableList<Strip>>(mutableListOf())
            var h = 0
            for (s in strips) {
                if (h + s.height > maxPartHeight && parts.last().isNotEmpty()) {
                    parts += mutableListOf<Strip>(); h = 0
                }
                parts.last() += s
                h += s.height
            }
            parts.forEachIndexed { index, list ->
                val total = list.sumOf { it.height }
                val out = Bitmap.createBitmap(width, total, Bitmap.Config.ARGB_8888)
                try {
                    val canvas = Canvas(out)
                    var y = 0f
                    for (s in list) {
                        val b = BitmapFactory.decodeFile(s.file.path) ?: continue
                        canvas.drawBitmap(b, 0f, y, null)
                        y += s.height
                        b.recycle()
                    }
                    writePart(out, index)
                } finally {
                    out.recycle()
                }
            }
        }

        fun maxPartHeightFor(width: Int): Int {
            val rt = Runtime.getRuntime()
            val free = rt.maxMemory() - (rt.totalMemory() - rt.freeMemory())
            val budget = (free * 0.45).toLong() // margine per compressione e UI
            val rows = budget / (width.toLong() * 4)
            return min(rows, 60_000L).toInt().coerceAtLeast(2_000)
        }
    }
}
