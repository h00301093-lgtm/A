package org.longscreen.tool

import android.content.Context

/**
 * Impostazioni persistenti. Ogni valore letto viene validato contro un insieme
 * chiuso di valori ammessi: un file di preferenze manomesso o corrotto non può
 * portare l'app in stati imprevisti.
 */
class AppSettings(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    enum class Step(val screenFraction: Float) { SHORT(0.35f), MEDIUM(0.50f), LONG(0.62f) }

    /** quietMs: attesa senza nuovi fotogrammi; maxMs: attesa massima dopo lo scorrimento. */
    enum class Settle(val quietMs: Long, val maxMs: Long) { NORMAL(350, 2000), SLOW(800, 4500) }

    enum class Format(val extension: String, val mime: String) {
        PNG("png", "image/png"), JPEG("jpg", "image/jpeg")
    }

    var step: Step
        get() = enumOrDefault(prefs.getString(KEY_STEP, null), Step.MEDIUM)
        set(v) = prefs.edit().putString(KEY_STEP, v.name).apply()

    var settle: Settle
        get() = enumOrDefault(prefs.getString(KEY_SETTLE, null), Settle.NORMAL)
        set(v) = prefs.edit().putString(KEY_SETTLE, v.name).apply()

    var format: Format
        get() = enumOrDefault(prefs.getString(KEY_FORMAT, null), Format.PNG)
        set(v) = prefs.edit().putString(KEY_FORMAT, v.name).apply()

    var maxHeight: Int
        get() = prefs.getInt(KEY_MAX_HEIGHT, DEFAULT_MAX_HEIGHT).let { if (it in ALLOWED_HEIGHTS) it else DEFAULT_MAX_HEIGHT }
        set(v) { if (v in ALLOWED_HEIGHTS) prefs.edit().putInt(KEY_MAX_HEIGHT, v).apply() }

    /** Rimuove barra di stato (orario, operatore, icone notifiche) e barra di navigazione. */
    var stripSystemBars: Boolean
        get() = prefs.getBoolean(KEY_STRIP_BARS, true)
        set(v) = prefs.edit().putBoolean(KEY_STRIP_BARS, v).apply()

    var termsAccepted: Boolean
        get() = prefs.getBoolean(KEY_TERMS, false)
        set(v) = prefs.edit().putBoolean(KEY_TERMS, v).apply()

    private inline fun <reified T : Enum<T>> enumOrDefault(raw: String?, def: T): T =
        enumValues<T>().firstOrNull { it.name == raw } ?: def

    companion object {
        private const val PREFS_NAME = "ls_settings"
        private const val KEY_STEP = "step"
        private const val KEY_SETTLE = "settle"
        private const val KEY_FORMAT = "format"
        private const val KEY_MAX_HEIGHT = "max_height"
        private const val KEY_STRIP_BARS = "strip_bars"
        private const val KEY_TERMS = "terms_v1"
        val ALLOWED_HEIGHTS = listOf(10_000, 20_000, 30_000)
        const val DEFAULT_MAX_HEIGHT = 20_000
    }
}
