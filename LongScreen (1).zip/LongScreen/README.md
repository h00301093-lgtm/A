# Long screen

Screenshot a scorrimento per Android, pensato per chi documenta fonti aperte: ricercatori OSINT, analisti di sicurezza, giornalisti investigativi, ricercatori accademici, analisti del contrasto all'estremismo.

L'app **non ha accesso a Internet**, non usa account né statistiche, e salva tutto nella memoria privata del telefono.

- **Dispositivo di riferimento:** Samsung Galaxy S9 con Android 10 (One UI 2).
- **Compatibilità:** Android 10–14.

---

## 1. Come ottenere l'app (senza competenze tecniche)

### Opzione A — GitHub, senza installare nulla sul computer
1. Crea un account gratuito su github.com, poi un **nuovo repository privato**.
2. Carica tutto il contenuto di questa cartella: pulsante *Add file → Upload files*, trascinando le cartelle.
   > La cartella `.github` può risultare nascosta. Se non viene caricata, crea a mano su GitHub il file `.github/workflows/build.yml` (*Add file → Create new file*) e incollaci il contenuto del file omonimo.
3. Apri la scheda **Actions**, scegli *Build APK* e poi *Run workflow*.
4. Dopo circa 5 minuti, apri l'esecuzione completata. In fondo alla pagina scarica **LongScreen-apk**: è uno zip che contiene `app-debug.apk`.

### Opzione B — Android Studio
1. Installa Android Studio (gratuito) e apri questa cartella con *Open*.
2. Attendi la sincronizzazione, poi scegli *Build → Build App Bundle(s)/APK(s) → Build APK(s)*.
3. Il file si trova in `app/build/outputs/apk/debug/app-debug.apk`.

### Installazione sul Galaxy S9
1. Copia l'APK sul telefono con un cavo USB, oppure salvalo nella cartella Download.
2. Aprilo da *Archivio* (My Files).
3. Alla richiesta, consenti *Installa app sconosciute* per l'app Archivio.
4. Conferma l'installazione. Al termine puoi ritirare quel permesso.

---

## 2. Primo avvio (una volta sola)

Nella sezione **1 · Configurazione iniziale** tutte le voci devono risultare "✓ Attivo".

| Permesso | A cosa serve | Cosa NON fa |
|---|---|---|
| Pulsante flottante | Mostra il pulsante di cattura sopra le altre app | Non legge nulla |
| Servizio di scorrimento (Accessibilità) | Esegue il gesto di scorrimento e intercetta i tasti volume per fermare la cattura | **Non legge testi o contenuti delle app** (`canRetrieveWindowContent=false`) |
| Cattura schermo | Chiesta a ogni sessione dal sistema | Legge lo schermo solo durante una cattura avviata da te |

Su Samsung il servizio si attiva da *Impostazioni → Accessibilità → Servizi installati → Long screen – scorrimento automatico*.

## 3. Uso

1. Tocca **Avvia sessione di cattura** e accetta il messaggio di sistema *Avvia ora*.
2. Apri la pagina web o l'app da documentare e posizionati dal punto da cui vuoi partire.
3. Tocca il **pulsante flottante**, che puoi trascinare dove preferisci. Il pulsante sparisce e lo schermo scorre da solo.
4. La cattura si ferma da sola:
   - a fine pagina;
   - al raggiungimento della lunghezza massima;
   - quando premi **un tasto volume**;
   - quando tocchi *Interrompi cattura* nella notifica.
5. Torna nell'app per trovare la cattura nell'**Archivio locale**. Dal menu ⋮ puoi:
   - visualizzarla;
   - aggiungere una nota, per esempio l'URL o il contesto;
   - esportare l'immagine o i metadati;
   - verificarne l'integrità;
   - eliminarla.
6. A fine lavoro scegli **Termina sessione**.

**Suggerimenti**
- Con pagine che caricano contenuti mentre scorri (social, commenti) usa l'attesa **Lenta**.
- Se la cattura si interrompe per "allineamento incerto", di solito per video o banner animati, usa l'ampiezza **Corta**.
- Le schermate protette dalle app (FLAG_SECURE: app bancarie, alcune chat) risultano nere. Il sistema ne impedisce la cattura e l'app te lo segnala.

---

## 4. Privacy e anonimato (privacy-by-design)

- **Nessuna rete.** Il permesso `INTERNET` è assente e viene rimosso esplicitamente in fase di build: l'app non può trasmettere nulla.
- **Nessun identificativo.** L'app non usa account, ID pubblicitari o analytics. Non registra modello del telefono, IMEI, posizione o rete.
- **Nomi file neutri.** I nomi seguono lo schema `LS_<data UTC>_<casuale>`, senza informazioni su di te.
- **Nessun EXIF.** PNG e JPEG sono generati senza metadati incorporati.
- **Barre di sistema rimosse** di default: orario, operatore, icone delle notifiche e batteria potrebbero ricondurre a te.
- **Memoria privata.** I file restano in `files/captures`, inaccessibile alle altre app e cifrata dal sistema (FBE). Backup cloud e trasferimenti tra dispositivi sono disattivati.
- **Esportazione solo su tua scelta**, tramite il selettore di sistema.
- **FLAG_SECURE** sulle schermate di Long screen: niente anteprime nelle "App recenti" e nessuno screenshot dell'archivio.
- **File temporanei cancellati** a ogni cattura e alla chiusura della sessione.

**Anonimato durante la raccolta.** L'app non lascia tracce proprie, ma lo screenshot riproduce ciò che vedi. Per restare anonimo verso la fonte:
- consulta i contenuti da un account o browser di ricerca non riconducibile a te;
- se serve, usa una VPN o Tor Browser. L'app funziona con qualsiasi browser, perché cattura lo schermo.
- controlla che nella cattura non compaiano il tuo nome utente, il tuo avatar o suggerimenti personalizzati.

## 5. Integrità e catena di custodia

Per ogni immagine viene creato un file `.json` con:
- data e ora UTC;
- dimensioni;
- numero di fotogrammi;
- motivo di fine cattura;
- eventuali giunzioni incerte;
- impronta **SHA-256** del file.

Le immagini esportate si possono verificare anche su computer: `sha256sum file.png` su Linux o macOS, `certutil -hashfile file.png SHA256` su Windows.

**Limiti di valore probatorio.** L'impronta dimostra che il file non è cambiato *dopo* la cattura. Non certifica la provenienza del contenuto. Per usi giudiziari affianca procedure di acquisizione forense certificate: marca temporale qualificata, verbale, eventuale acquisizione tramite terza parte.

---

## 6. Note tecniche

- **Linguaggio e dipendenze:** Kotlin, UI Material 3 con tema chiaro/scuro automatico. Le dipendenze sono solo AndroidX, Material e coroutines, con versioni fissate.
- **Cattura:** `MediaProjection` e `ImageReader`, attivi solo durante la sessione. In memoria resta solo l'ultimo fotogramma.
- **Scorrimento:** gesto via `AccessibilityService.dispatchGesture`. Il dito viene tenuto fermo prima del rilascio per evitare l'inerzia e ottenere spostamenti misurabili.
- **Cucitura:** a ogni riga di pixel si associa un'impronta (hash). Lo spostamento si ricava con una stima a maggioranza sulle righe informative. Intestazioni e barre fisse vengono rilevate automaticamente e compaiono una sola volta. Le strisce vanno su disco come PNG senza perdita e vengono ricomposte alla fine. Se la memoria non basta, l'immagine viene divisa in più parti invece di andare in crash.
- **Secure coding:**
  - componenti non esportati (tranne launcher e servizio di accessibilità, protetto da `BIND_ACCESSIBILITY_SERVICE`);
  - `PendingIntent` immutabili;
  - validazione dei nomi file con regex e controllo del percorso canonico contro il path traversal;
  - impostazioni validate su insiemi chiusi;
  - note sanificate e con lunghezza limitata;
  - scritture atomiche (tmp + rename);
  - confronto dell'hash a tempo costante;
  - nessun log di contenuti, e in release R8 elimina tutti i log;
  - `START_NOT_STICKY`;
  - `allowBackup=false`.
- **Non incluso per scelta:** condivisione diretta (FileProvider), WebView e qualunque componente di rete.

### Build di rilascio firmata (facoltativa)
L'APK *debug* va bene per uso personale. Per distribuire l'app a un team crea un keystore e configura `signingConfigs` in `app/build.gradle.kts`. Poi esegui `./gradlew assembleRelease`, che attiva minificazione e rimozione dei log.

### Uso responsabile
Usa lo strumento solo su contenuti a cui hai accesso legittimo, nel rispetto del GDPR, del diritto d'autore e delle norme deontologiche applicabili.
